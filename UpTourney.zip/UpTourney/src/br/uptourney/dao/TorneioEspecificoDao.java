package br.uptourney.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import br.uptourney.model.Torneio;
import br.uptourney.model.Usuario;
import br.uptourney.util.UpUtil;

public class TorneioEspecificoDao {

	Connection conexao = UpUtil.getConnection();
	
	HttpServletRequest request;
	
	public List<Torneio> listarTorneioEspecifico(Usuario usuario){
		
		List<Torneio> listarTorneioEspecifico = new ArrayList<>();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome_torneio from torneios");
			
			//preparedStatement pstm2 = conexao.prepareStatement();
			
			
			
			//pstm2.setString(1, usuario.getLogin());
			//pstm2.setString(2, usuario.getSenha());
			
		    //	ResultSet rs = pstm2.executeQuery();

			//Long idsUser = null;
			//while (rs.next()) {
			//	idsUser = rs.getLong("id_usuario");
			//}
			//System.out.println("ids: " + idsUser);
			//pstm.setLong(1, idsUser);
			ResultSet rs2 = pstm.executeQuery();
			
			while(rs2.next()){  
				Torneio torneio = new Torneio();
				torneio.setNome(rs2.getString("nome_torneio"));
				listarTorneioEspecifico.add(torneio);
		}
			
			pstm.close();
			rs2.close();
			
		}catch (SQLException e) {
			System.out.println("Pau no listar usuarioDB");
			e.printStackTrace();
		}
		System.out.println("Tentar imprim Lista");
		for (Torneio equipe : listarTorneioEspecifico) {
			System.out.println("Nome: " + equipe.getNome());
		}
		
		return listarTorneioEspecifico;
		

	}
}
		


