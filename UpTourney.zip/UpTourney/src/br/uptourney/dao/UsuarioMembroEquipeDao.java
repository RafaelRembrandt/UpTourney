package br.uptourney.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import br.uptourney.model.Equipe;
import br.uptourney.model.Usuario;
import br.uptourney.util.UpUtil;

public class UsuarioMembroEquipeDao {

	Connection conexao = UpUtil.getConnection();
	
	HttpServletRequest request;
	
	public List<Usuario> listarMembrosEquipes(Usuario usuario){
		
		List<Usuario> listaMembrosEquipe = new ArrayList<>();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome from usuarios us "+
					"inner join usuarios_equipes ue on (us.id_usuario = ue.id_usuario) "+
					"inner join equipes eq on (ue.id_equipe = eq.id_equipe) "+
					"where eq.id_equipe = ? "+
					"group by nome" );
			
			PreparedStatement pstm2 = conexao.prepareStatement("select id_equipe,nome_equipe from equipes eq "+
		             "inner join usuarios_equipes ue on (eq.id_equipe=ue.id_equipe) "+
		             "inner join usuarios u on(ue.id_usuario=u.id_usuario) "+
		             "where id_usuario=? "+
		             "group by id_equipe");
			PreparedStatement pstm3 = conexao.prepareStatement("select id_usuario from usuarios where login = ? and senha = ?");
			
			pstm3.setString(1, usuario.getLogin());
			pstm3.setString(2, usuario.getSenha());
			
			ResultSet rs3 = pstm3.executeQuery();
			
			
			Long idsUserX = null;
			while (rs3.next()) {
				idsUserX = rs3.getLong("id_usuario");
			}
			
		       pstm2.setLong(1, idsUserX);
			
			ResultSet rs = pstm2.executeQuery();
			String nomeEquipe = "";
			Long idsEquipe = null;
			while (rs.next()) {
				idsEquipe = rs.getLong("id_equipe");
				nomeEquipe = rs.getString("nome_equipe");
			}
			System.out.println("ids: " + idsEquipe);
			pstm.setLong(1, idsEquipe);

			ResultSet rs2 = pstm.executeQuery();
			
			while (rs2.next()) {
				System.out.println(rs2.getString("nome"));
				Usuario usuario1 = new Usuario();
				usuario1.setNome(rs2.getString("nome"));
				listaMembrosEquipe.add(usuario1);
			}
			System.out.println("<c:out value=" + nomeEquipe +"></c:out>" + "<\br>" ); 		
			
			pstm.close();
			pstm2.close();
			rs.close();
			rs2.close();
		} catch (SQLException e) {
			System.out.println("Pau no listar usuarioDB");
			e.printStackTrace();
		}
		System.out.println("Tentar imprim Lista");
		for (Usuario usuario1 : listaMembrosEquipe) {
			System.out.println("Nome: " + usuario1.getNome());
		}
		
		return listaMembrosEquipe;
		

	}

	public Equipe EquipeParticipante(Usuario usuario) {
		Equipe equipe = new Equipe();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome from equipes eq "+
					"inner join usuarios_equipes ue on (eq.id_equipe = ue.id_equipe) "+
					"inner join usuarios eq on (ue.id_usuario = eq.id_usuario) "+
					"where eq.id_usuario = ? "+
					"group by nome" );
			
			PreparedStatement pstm2 = conexao.prepareStatement("select id_usuario from usuarios where login = ? and senha = ?");
			
			pstm2.setString(1, usuario.getLogin());
			pstm2.setString(2, usuario.getSenha());
			
			ResultSet rs2 = pstm2.executeQuery();
			Long idsUser = null;
			while (rs2.next()) {
				idsUser = rs2.getLong("id_usuario");
			}
			String nomeEquipe = "";
			ResultSet rs = pstm.executeQuery();
			pstm.setLong(1, idsUser);
			while (rs.next()) {
				nomeEquipe = rs.getString("nome_equipe");
			}
			System.out.println(nomeEquipe + "UsuarioMembroEquipeDao1");

			ResultSet rs3 = pstm.executeQuery();
			
			while (rs3.next()) {
				equipe.setNomeEquipe(rs3.getString("nome"));
			}
			System.out.println(nomeEquipe + "UsuarioMembroEquipeDao2");
			if(equipe.getNomeEquipe().equals(null)){
				equipe.setNomeEquipe(nomeEquipe);
			}
			System.out.println(nomeEquipe + "UsuarioMembroEquipeDao3");
			pstm.close();
			pstm2.close();
			rs.close();
			rs2.close();
		} catch (SQLException e) {
			System.out.println("Pau no listar usuarioDB");
			e.printStackTrace();
		}
			
		return equipe;
	}
}
