package br.uptourney.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.uptourney.model.Equipe;
import br.uptourney.model.Organizacao;
import br.uptourney.model.Usuario;
import br.uptourney.util.UpUtil;

public class UsuarioBdDao {

	Connection conexao = UpUtil.getConnection();
	
	public List<Equipe> listarEquipesDoUsuario(Usuario usuario){
		
		List<Equipe> listaEquipeDoUsuario = new ArrayList<>();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome_equipe from equipes eq " +
			"inner join usuarios_equipes ue on (eq.id_equipe = ue.id_equipe)  " +
			"inner join usuarios us on (ue.id_usuario = us.id_usuario)  " +
			"where id_usuario = ?");
			
			PreparedStatement pstm2 = conexao.prepareStatement("select id_usuario from usuarios where login = ? and senha = ?");
			
			pstm2.setString(1, usuario.getLogin());
			pstm2.setString(2, usuario.getSenha());
			
			ResultSet rs = pstm2.executeQuery();

			Long idsUser = null;
			while (rs.next()) {
				idsUser = rs.getLong("id_usuario");
			}
			System.out.println("ids: " + idsUser);
			pstm.setLong(1, idsUser);

			ResultSet rs2 = pstm.executeQuery();
			
			while (rs2.next()) {
				System.out.println(rs2.getString("nome_equipe"));
				Equipe equipe = new Equipe();
				equipe.setNomeEquipe(rs2.getString("nome_equipe"));
				listaEquipeDoUsuario.add(equipe);
			}
			
			pstm.close();
			pstm2.close();
			rs.close();
			rs2.close();
		} catch (SQLException e) {
			System.out.println("Pau no listar usuarioDB");
			e.printStackTrace();
		}
		System.out.println("Tentar imprim Lista");
		for (Equipe equipe : listaEquipeDoUsuario) {
			System.out.println("Nome: " + equipe.getNomeEquipe());
		}
		
		return listaEquipeDoUsuario;
		

	}
	
	public List<Organizacao> listarOrganizacaoUsuario(Usuario usuario){
		
		List<Organizacao> listaOrganizacaoUsuarios = new ArrayList<>();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome_organizacao from organizacoes org " +
					"inner join usuarios_organ uo on (org.id_organizacao = uo.id_organizacao)  " +
					"inner join usuarios us on (uo.id_usuario = us.id_usuario)  " +
					"where id_usuario = ?");
			
			PreparedStatement pstm2 = conexao.prepareStatement("select id_usuario from usuarios where login = ? and senha = ?");
			
			pstm2.setString(1, usuario.getLogin());
			pstm2.setString(2, usuario.getSenha());
			
			ResultSet rs = pstm2.executeQuery();

			Long idsUser = null;
			while (rs.next()) {
				idsUser = rs.getLong("id_usuario");
			}
			System.out.println("ids: " + idsUser);
			pstm.setLong(1, idsUser);

			ResultSet rs2 = pstm.executeQuery();
			
			while (rs2.next()) {
				System.out.println(rs2.getString("nome_organizacao"));
				Organizacao org = new Organizacao();
				org.setNome(rs2.getString("nome_organizacao"));
				listaOrganizacaoUsuarios.add(org);
			}
			
			pstm.close();
			pstm2.close();
			rs.close();
			rs2.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listaOrganizacaoUsuarios;
		
	}
	
	public List<Organizacao> listarOganizacaoLider(Usuario usuario){
		
		List<Organizacao> listaOrganizacaoLider = new ArrayList<>();
		
		try {
			PreparedStatement pstm = conexao.prepareStatement("select nome_organizacao from organizacoes org " +
					"inner join usuarios_organ uo on (org.id_organizacao = uo.id_organizacao)  " +
					"inner join usuarios us on (uo.id_usuario = us.id_usuario) " +
					"where id_user_liderorg = ? "
					+ "group by nome_organizacao");
			
			
			PreparedStatement pstm2 = conexao.prepareStatement("select id_usuario from usuarios where login = ? and senha = ?");
			
			pstm2.setString(1, usuario.getLogin());
			pstm2.setString(2, usuario.getSenha());
			
			ResultSet rs = pstm2.executeQuery();

			Long idsUser = null;
			while (rs.next()) {
				idsUser = rs.getLong("id_usuario");
			}
			System.out.println("ids: " + idsUser);
			pstm.setLong(1, idsUser);
			
			ResultSet rs2 = pstm.executeQuery();
			
			while (rs2.next()) {	
				Organizacao org = new Organizacao();
				org.setNome(rs2.getString("nome_organizacao"));
				listaOrganizacaoLider.add(org);
			}
			
			pstm.close();
			pstm2.close();
			rs.close();
			rs2.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return listaOrganizacaoLider;
		
		
	}
	
}
